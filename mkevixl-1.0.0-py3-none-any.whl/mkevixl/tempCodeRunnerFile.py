import click

# from excel_handler import make_file
from mkevixl.excel_handler import make_file

# from excel_handler import make_file


@click.command()
@click.option("--filename", "-f", default="newfile", show_default=True, help="ファイル名称")
@click.option(
    "--start",
    "-st,
    default=1,
    show_default=True,
    type=int,
    help="シート名称の開始値",
)
@click.option(
    "--sheetcount", "-sh", default=1, show_default=True, type=int, help="モード2用:追加するシート数"
)
def cli(filename, start ,sheetcount):
    # https://blog.amedama.jp/entry/2015/10/14/232045
    # エビデンス用Excelファイル生成ツール
    # click.echo(arg_name, filename)
    # print(arg_name, filename)
    # if len(sheetnames) == 0:
    #     sheetnames = sheetnames + ("new")
    print(filename, start ,sheetcount)
    # mkevixl(mode, filename, sheetcount, sheetnames)
    # 動確用
    # click.echo(filename)


def mkevixl(mode, filename, sheetcount, sheetnames):

    if mode != 1 and mode != 2:
        return False

    if mode == 2:
        if isint(sheetnames[0]) == False:
            return False

    make_file(mode, filename, sheetcount, sheetnames)


def isint(s):
    try:
        int(s)
    except ValueError:
        print("valuerr")
        return False
    else:
        return True
